//
//  AppDelegate.h
//  SSPopup
//
//  Created by Karthick Baskar on 25/10/16.
//  Copyright © 2016 Karthick Baskar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

